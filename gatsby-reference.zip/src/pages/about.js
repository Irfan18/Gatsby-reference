import React from 'react';
import { Link } from 'gatsby';
import Layout from '../components/layout';

const AboutPage = () => {
    return (
        <Layout>
            <h1>About Us Page</h1>
            <p>This page is all about testing pls dont take it seriouslt... Just Chill</p>
            <p><Link to="/contact">Contact us</Link></p>
        </Layout>
    )
}

export default AboutPage;