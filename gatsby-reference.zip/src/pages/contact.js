import React from 'react';
import { Link } from 'gatsby';
import Layout from '../components/layout';

const ContactPage = () => {
    return (
        <Layout>
            <h1>Contact Us Page</h1>
            <p>202,2 Niwas, Pratap Nagar Road, Bhandup West</p>
            <p>+91 9966332222</p>
            <p>My twitter handle <Link to='https://t.co/NJY7giyFC0?amp=1'>@irfanShaikh</Link></p>
        </Layout>
    )
}

export default ContactPage;