---
title: "The Great Gatsby Bootcamp"
date: "2020-06-15"
---

I just launched a new bootcamp!

## Topics Covered

1. Gatsby
2. Graphql
3. React
